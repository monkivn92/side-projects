<?php

defined('_JEXEC') or die;

class PlgSystemBasicauth extends JPlugin
{

	function onAfterInitialise()
	{
		print_r($this->params);
	}
	
}
