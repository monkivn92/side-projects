
<?php

defined('_JEXEC') or die;
$colors = array( '1' => '#272822',
					'2' => '#F92672',
					'3' => '#66D9EF',
					'4' => '#A6E22E',
					'5' => '#FD971F');
									
?>

<div class="container">
	<div id="module-search">
		<?php
			jimport('joomla.application.module.helper');
			$modules = JModuleHelper::getModules('position-0','Search Content');
			//var_dump($modules);
			foreach ($modules as $module)
			{
			  echo JModuleHelper::renderModule($module);
			}
		?>
	</div>
	<?php
	$color_cnt = 1;
	foreach ($list as $key => $node)
	{
		echo "<div class='cat_item monokai$color_cnt'>";
		echo '<span>';
		echo $node->title;
		echo '('.$node->numitems.')';
		echo '<span>';
		echo '</div>';

		if($color_cnt==5)
		{
			$color_cnt = 1;
		}
		else
		{
			$color_cnt++;
		}
	}
	
	?>

</div>

<style>
	#cat-undertopmenu{
		height: 480px;
		background-image: url('/images/working/lzg0j7.png');
	}
	#module-search{
		text-align: center;
		margin: 60px 30px 0px;
	}
	#module-search input{
		width: 60% !important;
		height: 30px;
		border-radius: 30px;
	}
	#cat-undertopmenu .cat_item{
		width: 22%;		
		
		border-radius: 0px 30px 0px 30px/0px 30px 0px 30px;
		display: inline-block;
		margin: 10px;
		text-align: center;
		color: #FFF;
		font-weight: bold;
		font-size: 20px;
		box-shadow: none;
		text-transform: uppercase;

	}
	#cat-undertopmenu .cat_item span{
		display: block;
		margin:40px 0px;
	}
	#cat-undertopmenu .monokai1{
		background-color: #272822;
		
	}
	#cat-undertopmenu .monokai1:hover{
		box-shadow: 0px 0px 6px red;
	}
	#cat-undertopmenu .monokai2{
		background-color: #F92672;
		
	}
	#cat-undertopmenu .monokai2:hover{
		box-shadow: 0px 0px 6px #272822;
	}
	#cat-undertopmenu .monokai3{
		background-color: #66D9EF;
		
	}
	#cat-undertopmenu .monokai3:hover{
		box-shadow: 0px 0px 6px #272822;
	}
	#cat-undertopmenu .monokai4{
		background-color: #A6E22E;
		
	}
	#cat-undertopmenu .monokai4:hover{
		box-shadow: 0px 0px 6px #272822;
	}
	#cat-undertopmenu .monokai5{
		background-color: #FD971F;
		
	}
	#cat-undertopmenu .monokai5:hover{
		box-shadow: 0px 0px 6px #272822;
	}
</style>




