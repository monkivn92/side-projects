<?php

defined('_JEXEC') or die;

$catid = $params->get('catid');
$bgimg = $params->get('bgimg');

require JModuleHelper::getLayoutPath('mod_mainmenu', $params->get('layout', 'default'));

